
#import "HTTPConnection.h"


@interface SystemConfigConnection : HTTPConnection

@end
