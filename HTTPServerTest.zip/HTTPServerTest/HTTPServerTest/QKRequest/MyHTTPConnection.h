
#import "HTTPConnection.h"


@interface MyHTTPConnection : HTTPConnection

@end