
#import "HTTPConnection.h"


@interface KeyStateConnection : HTTPConnection

@end