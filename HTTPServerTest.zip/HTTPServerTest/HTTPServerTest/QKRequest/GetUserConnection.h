
#import "HTTPConnection.h"


@interface GetUserConnection : HTTPConnection

@end