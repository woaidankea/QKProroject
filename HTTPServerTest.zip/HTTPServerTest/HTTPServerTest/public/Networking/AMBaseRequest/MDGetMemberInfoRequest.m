//
//  MDGetMemberInfoRequest.m
//  MDApplication
//
//  Created by jieku on 16/3/22.
//  Copyright © 2016年 jieku. All rights reserved.
//

#import "MDGetMemberInfoRequest.h"

@implementation MDGetMemberInfoRequest

@end
