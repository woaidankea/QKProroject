//
//  AMHTTPRequestSerializer.h
//  AMen
//
//  Created by Draco Wang on 15-8-17.
//  Copyright (c) 2015年 gaoxinfei. All rights reserved.
//

#import "AFURLRequestSerialization.h"

@interface AMHTTPRequestSerializer : AFHTTPRequestSerializer

@end
