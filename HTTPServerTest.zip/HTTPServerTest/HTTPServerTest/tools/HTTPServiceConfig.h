//
//  HTTPServiceConfig.h
//  HTTPServerTest
//
//  Created by jieku on 16/7/14.
//  Copyright © 2016年 董宪. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HTTPServer.h"
@interface HTTPServiceConfig : NSObject
+ (void)HttpServiceConfig:(HTTPServer *)httpservice;
@end
