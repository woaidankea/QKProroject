//
//  EngineerOrderCell.m
//  Medicalmmt
//
//  Created by jieku on 16/5/12.
//  Copyright © 2016年 gulei. All rights reserved.
//

#import "EngineerOrderCell.h"

@implementation EngineerOrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
